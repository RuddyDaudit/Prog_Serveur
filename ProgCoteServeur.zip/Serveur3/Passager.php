<?php
	class Passager{
	public $idTrajet; 
	public $loginPassager;
	
	
	function __construct(){
		$a  = func_get_args();
		$i  = func_get_args();
		echo var_dump($a);
		if($i>0)
				$this->__construct1($a);
	}

	function __construct1($a){
				$this->idTrajet= $a[0];
				$this->loginPassager = $a[1];
	}

	function geIdTrajet{
		return $this->idTrajet;
	}
	function getLoginPassager(){
		return $this->loginPassager;
	}
	

	function setIdTrajet($idTrajet){
		$this->idTrajet = $idTrajet;
	}
	function setLoginPassager($loginPassager){
		$this->loginPassager = $loginPassager;
	}
	

}