<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>liste Voiture</title>
</head>
<body>
<?php
$DS = DIRECTORY_SEPARATOR;
        $CUR = dirname(dirname(__DIR__));
        require_once( $CUR . $DS . "modele" . $DS .  "ModelVoiture.php"); 
        $tab = Voiture::getAll() ;
        
        echo "<h1>Liste des voitures </h1>";
        echo  "<ul>";
        foreach ($tab as $v)
        {
            echo '<li>' . $v->getImmatriculation()  . '<a href='.$DS.'vue' . $DS . 'voiture' . $DS .  'detail.php?immatriculation=' .  $v->getImmatriculation()  . '> (Détails)  </a></li>'; 
        }
        echo "</ul>"; 
?>

</body>
</html>