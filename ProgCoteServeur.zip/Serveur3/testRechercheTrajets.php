<!DOCTYPE html>
<html>
<head>
</head>
<?php
require("connexion.php");

try {
$db = new PDO("mysql:host=$host;dbname=$db",$login,$mdp);

$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$SQL = "SELECT * FROM trajet INNER JOIN passager ON passager.loginPassager = trajet.login INNER JOIN trajet ON passager.idTrajet = trajet.id WHERE passager.login = $_GET['id']";

$st = $db->prepare($SQL);
$res = $st -> execute();
//$row = $st -> fetch();
	if($st->rowCount()==0){
		echo"<p>La liste est vide";
	}
	else{
		?> <table class= "table table-striped">
		<thead>
		<th>id</th>
		<th>Départ</th>
		<th>Arrivée</th>
		<th>Prix</th>
		<th>Date</th>
		<th>NbPlaces</th>
		<th>idConducteur</th>
		</thead>
<?php		
foreach ($st as $row){
?>	
<tr>
	<td><?php echo htmlspecialchars($row['id'])?></td>
	<td><?php echo htmlspecialchars($row['depart'])?></td>
	<td><?php echo htmlspecialchars($row['arrivee'])?></td>
	<td><?php echo htmlspecialchars($row['prix'])?></td>
	<td><?php echo htmlspecialchars($row['date'])?></td>
	<td><?php echo htmlspecialchars($row['nbPlaces'])?></td>
	<td><?php echo htmlspecialchars($row['idConductzue'])?></td>

</tr>

<?php
	}

echo"</table>\n";
	}
}
catch(PDOException $e){

echo("Erreur de connexion" .$e->getMessage());
}

?>

</body>
</html>