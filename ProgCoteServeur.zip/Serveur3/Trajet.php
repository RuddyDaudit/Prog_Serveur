<?php
	class Trajet{
	public $id; 
	public $depart;
	public $arrivee;
	public $prix;
	public $date;
	public $nbPlaces;
	public $idConductzue;

	
	function __construct(){
		$a  = func_get_args();
		$i  = func_get_args();
		echo var_dump($a);
		if($i>0)
				$this->__construct1($a);
	}

	function __construct1($a){
				$this->id= $a[0];
				$this->depart = $a[1];
				$this->arrivee = $a[2];
				$this->prix = $a[3];
				$this->date = $a[4];
				$this->nbPlaces = $a[5];
				$this->idConductzue = $a[6];
	}

	function getId{
		return $this->id;
	}
	function getDepart(){
		return $this->depart;
	}
	function getArrivee(){
		return $this->arrivee;
	}
	function getPrix(){
		return $this->prix;
	}
	function getDate(){
		return $this->date;
	}
	function getNbPlaces(){
		return $this->nbPlaces;
	}
	function getIdConducteur(){
		return $this->idConductzue;
	}

	function setMarque($id){
		$this->id = $id;
	}
	function setCouleur($depart){
		$this->depart = $depart;
	}
	function setLogin($arrivee){
		$this->arrivee = $arrivee;
	}
	function setLogin($prix){
		$this->prix = $prix;
	}
	function setLogin($date){
		$this->prix = $prix;
	}
	function setLogin($nbPlaces){
		$this->nbPlaces = $nbPlaces;
	}
	function setLogin($idConductzue){
		$this->idConductzue = $idConductzue;
	}

}