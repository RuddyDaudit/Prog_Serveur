<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php
$page_title = "Supprimer Trajet";

if (!isset($_GET['idTrajet']) || ($_GET['loginPassager'])) {
	echo"<p>ERREUR </p>\n";
}else if(!isset($_POST['supprimer']) && !isset($_POST['annuler']) ) {
	include ("formulaireSupprimer.php");
}else if (isset($_POST['annuler'])) {
	echo"Operation annulee";
	} else {
		//supprimer
		require("connexion.php");
		
		try{
		$db = new PDO("mysql:host=$host;dbname=$db",$login,$mdp);
		$db ->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
		$SQL = "DELETE FROM trajet WHERE idTrajet=?, loginPassager=?";
		$idTrajet=$_GET['idTrajet'];
		$loginPassager=$_GET['loginPassager'];
		$st = $db->prepare($SQL);
		$st->execute([$id]);
		
		if(!$st){
			echo "<p>Erreur de suppression<p>\n";
		}
		else echo"<p>La suppression a été éffectuée<p>";
		$db=null;
	}
		catch(PDOExecption $e){
			echo"Erreur SQL:".$e->getMessage();
	} 
}
?>
</body>
</html>