<?php

class Info{
	static private $db = array(
	’hostname’   => ’localhost’,
	’database’   => ’Covoiturage’,
	’login’      => ’root,
	’password’   => ’’);
	
	static public function getLogin(){
		return self::$database[’login’];
	}
?>