<?php
	class Utilisateur{
	public $nom; 
	public $prenom;
	public $login;

	function __construct(){
		$a  = func_get_args();
		$i  = func_get_args();
		echo var_dump($a);
		if($i>0)
				$this->__construct1($a);
	}

	function __construct1($a){
			$this->nom = $a[0];
			$this->prenom = $a[1];
			$this->login = $a[2];
	}	

	function getNom(){
		return $this->nom;
	}
	function getPrenom(){
		return $this->prenom;
	}
	function getLogin(){
		return $this->login;
	}

	function setMarque($nom){
		$this->nom = $nom;
	}
	function setCouleur($prenom){
		$this->prenom = $prenom;
	}
	function setLogin($login){
		$this->login = $login;
	}

}