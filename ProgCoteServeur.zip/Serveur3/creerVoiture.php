 <?php
$page_title = "création d'une voiture";

if(!isset($_GET['immatriculation'])|| !isset($_GET['couleur'])|| !isset($_GET['marque'])) {
  include("formulaireVoiture.php");
}else{
  $immatriculation=$_GET['immatriculation'];
  $couleur=$_GET['couleur'];
  $marque = $_GET['marque'];

  //Vérification
  if($immatriculation==""||$couleur==""||$marque=="" ){
    include("formulaireVoiture.php");
  }else{
  //creation d'un objet
    $uneVoiture = new Voiture();
    return $uneVoiture;
  }
}

     
    