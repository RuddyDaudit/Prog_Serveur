<html>
<head>
<meta charset="UTF-8">
<title>Liste des voitures</title>
</head>
<body>
<?php
	require_once ("model/ModelVoiture.php");
	foreach ($arrayVoitures as $v)
	echo ’<p> Voiture d\’immat ’ . $v->getImmatriculation() . ’.</p>’;
?>
</body>
</html>