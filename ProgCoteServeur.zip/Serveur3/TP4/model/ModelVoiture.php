<?php

$mv->save();
$mv2 = ModelVoiture::getByImmat($immatriculation);
$arrayVoitures = ModelVoiture::getAll();