<?php
require_once ("model/ModelVoiture.php");
$array_voitures = ModelVoiture::getAll();
require ("vue/list.php");
?>