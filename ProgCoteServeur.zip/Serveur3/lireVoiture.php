<!DOCTYPE html>
<html>
<head>
	<title>lire des voiures</title>
</head>
<body>
<?php
require('connexion.php');
require_once 'Voiture.php';

Voiture::getAll();
Voiture::getByImmat($immatriculation);
$this = new Voiture();
Voiture::save($this);

?>
</body>
</html>