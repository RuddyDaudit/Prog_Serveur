<?php
	class Trajet{
	public $id; 
	public $depart;
	public $arrivee;
	public $prix;
	public $date;
	public $nbPlaces;
	public $idConductzue;

	
	function __construct($id, $depart,$arrivee,$prix,$date,$nbPlaces,$idConductzue){
		if(! is_null($id) && ! is_null($depart) && ! is_null($arrivee)&& ! is_null($prix)&& ! is_null($date)&& ! is_null($nbPlaces)&& ! is_null($idConductzue)){
				$this->id= $id;
				$this->depart = $depart;
				$this->arrivee = $arrivee;
				$this->prix = $prix;
				$this->date = $date;
				$this->nbPlaces = $nbPlaces;
				$this->idConductzue = $idConductzue;
		}
	}

	function getId{
		return $this->id;
	}
	function getDepart(){
		return $this->depart;
	}
	function getArrivee(){
		return $this->arrivee;
	}
	function getPrix(){
		return $this->prix;
	}
	function getDate(){
		return $this->date;
	}
	function getNbPlaces(){
		return $this->nbPlaces;
	}
	function getIdConducteur(){
		return $this->idConductzue;
	}

	function setMarque($id){
		$this->id = $id;
	}
	function setCouleur($depart){
		$this->depart = $depart;
	}
	function setLogin($arrivee){
		$this->arrivee = $arrivee;
	}
	function setLogin($prix){
		$this->prix = $prix;
	}
	function setLogin($date){
		$this->prix = $prix;
	}
	function setLogin($nbPlaces){
		$this->nbPlaces = $nbPlaces;
	}
	function setLogin($idConductzue){
		$this->idConductzue = $idConductzue;
	}

}