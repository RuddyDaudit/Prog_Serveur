	<?php
	class Voiture{
	public $marque; 
	public $couleur;
	public $immatriculation;

	

	function __construct($marque = null,$couleur = null,$immatriculation = null){
		if(!is_null($marque) && !is_null($couleur) && !is_null($immatriculation){
			$this->marque = $marque;
			$this->couleur = $couleur;
			$this->immatriculation = $immatriculation;
		}
	}


	function getMarque(){
		return $this->marque;
	}
	function getCouleur(){
		return $this->couleur;
	}
	function getImmatriculation(){
		return $this->immatriculation;
	}

	function setMarque($marque){
		$this->marque = $marque;
	}
	function setCouleur($couleur){
		$this->couleur = $couleur;
	}
	function setImmatriculation($immatriculation){
		$this->immatriculation = $immatricualtion;
	}
	function affichage(){
		$echo "la marque de la voiture est ".$marque." elle est de couleur " .$couelur " et sa plaque est " .$immatriculation;
	}

}
?>