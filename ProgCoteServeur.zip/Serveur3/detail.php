<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Détails de la voiture</title>
</head>
<body>
<?php
$DS = DIRECTORY_SEPARATOR;
        $CUR = dirname(dirname(__DIR__));
        require_once( $CUR  . $DS . "modele" . $DS .  "ModelVoiture.php"); 
        $tab = Voiture::getByImmat($_GET["immatriculation"]);
        if( count($tab) == 0 )
        {
           require($CUR . $DS . "vue" . $DS . "voiture");
        } else
        {
           echo "<h2>  Les détails de la voiture  </h2> ";
           echo  "<ul>";
           foreach ($tab as $v) 
           {
              echo  "<li> Marque  = " .  $v->getMarque()  ."</li>";
              echo  "<li> Couleur = " .  $v->getCouleur()  ."</li>";
              echo  "<li> Immatriculation=" . $v->getImmatriculation() . "</li>";   
           }
            echo "</ul>"; 
        }
?>
</body>
</html>