<!DOCTYPE html>
<html>
<head>
	<title>exercice 2</title>
</head>
<body>
	<?php
	require_once('Voiture.php');
	affichage()
	?>

</body>
</html>