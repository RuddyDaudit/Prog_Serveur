<?php
 $couleur = $_POST['couleur'];
 $immatriculation = $_POST['immatriculation'];
 $marque = $_POST['marque'];
 ?>