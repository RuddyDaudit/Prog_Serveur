	<?php
	class Voiture{
	public $marque; 
	public $couleur;
	public $immatriculation;

	
	function __construct(){
		
	}

	function __construct($marque,$couleur,$immatriculation){
	$this->marque = $marque;
	$this->couleur = $couleur;
	$this->immatriculation = $immatriculation;
	}


	function getMarque(){
		return $this->marque;
	}
	function getCouleur(){
		return $this->couleur;
	}
	function getImmatriculation(){
		return $this->immatriculation;
	}

	function setMarque($marque){
		$this->marque = $marque;
	}
	function setCouleur($couleur){
		$this->couleur = $couleur;
	}
	function setImmatriculation($immatriculation){
		$this->immatriculation = $immatricualtion;
	}
	function affichage(){
		$echo "la voiture est bleu";
	}

}
?>