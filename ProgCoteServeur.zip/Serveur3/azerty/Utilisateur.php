<?php
	class Utilisateur{
	public $nom; 
	public $prenom;
	public $login;

	function __construct($nom,$prenom,$login;
){
	$this->nom = $nom;
	$this->prenom = $prenom;
	$this->login = $login;
	}

	function getNom(){
		return $this->nom;
	}
	function getPrenom(){
		return $this->prenom;
	}
	function getLogin(){
		return $this->login;
	}

	function setMarque($nom){
		$this->nom = $nom;
	}
	function setCouleur($prenom){
		$this->prenom = $prenom;
	}
	function setLogin($login){
		$this->login = $login;
	}

}