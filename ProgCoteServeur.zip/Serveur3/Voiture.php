	<?php
	class Voiture{
	public $marque; 
	public $couleur;
	public $immatriculation;

	

	function __construct(){
		$a  = func_get_args();
		$i  = func_get_args();
		echo var_dump($a);
		if($i>0)
				$this->__construct1($a);
	}

	function __construct1($a){
			$this->marque = $a[0];
			$this->couleur = $a[1];
			$this->immatriculation = $a[2];
	}


	function getMarque(){
		return $this->marque;
	}
	function getCouleur(){
		return $this->couleur;
	}
	function getImmatriculation(){
		return $this->immatriculation;
	}

	function setMarque($marque){
		$this->marque = $marque;
	}
	function setCouleur($couleur){
		$this->couleur = $couleur;
	}
	function setImmatriculation($immatriculation){
		$this->immatriculation = $immatricualtion;
	}
	function affichage(){
		$echo "la marque de la voiture est ".$marque." elle est de couleur " .$couelur " et sa plaque est " .$immatriculation;
	}
	
	function getAll(){
		$req = "select * from voiture";
    	$res = $res = PdoBouquet::$monPdo->query($req);
		$lesVoitures = array();
		$lesVoitures = $res->fetchAll();
		return $lesVoitures;	
	}

	static function getBYImmat($immatriculation){
		$st = $db->prepare($SQL); 
  		$val= array ($immatriculation);
  		$st-> execute($val);
	}

}
?>