<?php
$DS = DIRECTORY_SEPARATOR;
$CUR = dirname(__DIR__);
require_once($CUR  .  $DS . "controleur" . $DS . "controllerVoiture.php");  

if( $_GET["action"] == "readAll" )
    controllerVoiture::readAll();
else if( $_GET["action"] == "create" )
    controllerVoiture::create();
?>
 
