<?php
require_once (’../model/ModelVoiture.php’);
$array_voitures = ModelVoiture::getAll();
require (’../view/voiture/list.php’);
?>