<!DOCTYPE html>
<html>
<head>
</head>
<?php
require("connexion.php");

try {
$db = new PDO("mysql:host=$host;dbname=$db",$login,$mdp);

$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$SQL = "SELECT * FROM utilisateur INNER JOIN passager ON passager.loginPassager = trajet.login INNER JOIN trajet ON passager.idTrajet = trajet.id WHERE passager.login = $_GET['id']";

$st = $db->prepare($SQL);
$res = $st -> execute();
//$row = $st -> fetch();
	if($st->rowCount()==0){
		echo"<p>La liste est vide";
	}
	else{
		?> <table class= "table table-striped">
		<thead>
		<th>login</th>
		<th>Nom</th>
		<th>Prenom</th>
		</thead>
<?php		
foreach ($st as $row){
?>	
<tr>
	<td><?php echo htmlspecialchars($row['login'])?></td>
	<td><?php echo htmlspecialchars($row['nom'])?></td>
	<td><?php echo htmlspecialchars($row['prenom'])?></td>

</tr>

<?php
	}

echo"</table>\n";
	}
}
catch(PDOException $e){

echo("Erreur de connexion" .$e->getMessage());
}

?>

</body>
</html>