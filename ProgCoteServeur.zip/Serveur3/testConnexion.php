<?php

$hostname = "localhost";
$database = "Covoiturage";
$login = "root";
$password = " ";

if(PDO("mysql:host=$hostname;db=$database",$login,$password))
 		{ 
 			echo "Succès !";//Ça roule !
 		
 		}else{
 			
 			die("Echec");
 		}
 
?>