<?php
	
$hostname="localhost";
$database="Covoiturage";
$login = "login";
$password = "password";
$conn = " ";

	try{
		
		$conn = new PDO("mysql:host=$hostname;db=$database",$login,$password);
		
	}catch (PDOException $e){
		$e->getMessage();
	}
	
